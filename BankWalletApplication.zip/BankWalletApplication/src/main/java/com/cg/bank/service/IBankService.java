package com.cg.bank.service;

import java.util.List;

import com.cg.bank.bean.Bank;
import com.cg.bank.exception.BankException;

public interface IBankService {

	public List<Bank> addBank(Bank bankcustomer) throws BankException;
	public List<Bank> getAllBankDetials() throws BankException;
	public Bank showBalance(int accountnum) throws BankException;
	
    
    
    
    public Bank getCustomerByLoginDetails(String username, String password) throws BankException;
    
    public Bank depositMoney(int accountnum, int amount) throws BankException;
    
    public Bank withdrawMoney(int accountnum, int amount) throws BankException;
    
    
    public Bank fundTransfer(int accountnum1, int accountnum2, int amount) throws BankException;
	
}
