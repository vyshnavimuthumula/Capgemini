package com.cg.bank.dao;



import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.cg.bank.bean.Bank;
import com.cg.bank.exception.BankException;

@Repository
public interface BankDao extends JpaRepository<Bank, Integer>{

	//@Query("from Bank where accountnum=:accountnum")
	//List<Bank> getBankDetailsByAccountnum(String accountnum);
	
	
}
