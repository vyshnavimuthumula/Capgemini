export interface IEmployee {

    "empId":number;
    "empName":string;
    "empSal":number;
    "empDep":string;

}
