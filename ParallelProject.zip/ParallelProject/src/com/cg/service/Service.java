package com.cg.service;
import java.util.List;
import java.util.Scanner;

import com.cd.dao.DataStorage;
import com.cg.bean.Bank;


public class Service {	

	
	Scanner sc = new Scanner(System.in);
	
	DataStorage database=new DataStorage();
	
	
     	public void accountDetails() {
     		
     	Bank bank = new Bank();
		System.out.print("Enter your name:");
		bank.setName(sc.next());
		System.out.print("Enter Adhaar details:");
		bank.setAdharNum(sc.next());
		System.out.print("Enter your Mobile Number:");
		bank.setPhoneNum(sc.next());
		bank.setAccnum();
		System.out.println("set the pin to the account");
		bank.setPin(sc.nextInt());
		System.out.println("Enter the amount to be deposited");
		bank.setBalance(sc.nextInt());
		System.out.println("Account created successfully");
		System.out.println("Your Account Number is: "+bank.getAccnum());
		database.storeCustomerDetails(bank);		
		
	}
     	
	public int showBalance() {
		
		int accountno;
		int pin;
		System.out.println("Enter account number");
		accountno = sc.nextInt();
		System.out.println("Enter your pin");
		pin=sc.nextInt();
		List<Bank> custList=database.getCustomerDetails();
		for(Bank cust:custList) {
			if(cust.getAccnum()==accountno && cust.getPin()==pin)
				return cust.getBalance();
		}
		return 0;			
					
	}
	
	
	
	
	public int dataDeposit() {
		int accountno;
		System.out.println("Enter the account no");
		accountno = sc.nextInt();
		List<Bank> custList=database.getCustomerDetails();
		Bank bank= new Bank();
		for(Bank cust:custList) {
			if(cust.getAccnum()==accountno){
				System.out.println("Enter the amount to be depoist: ");
				int amount = sc.nextInt();
				cust.setBalance(cust.getBalance()+amount);
				return cust.getBalance();	
			}
		}
		return 0;
	}

	public void withDrawal() {
		// TODO Auto-generated method stub
		
	}
	public void fundTrans() {
		// TODO Auto-generated method stub
		
	}

	public void printTransaction() {
		// TODO Auto-generated method stub
		
	}

}
