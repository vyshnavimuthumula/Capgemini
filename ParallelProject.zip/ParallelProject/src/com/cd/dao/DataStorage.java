package com.cd.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Bank;


public class DataStorage {
	
	static List<Bank> list=new ArrayList<Bank>();
	
	//Storing the data
	public void storeCustomerDetails(Bank bank) {
		list.add(bank);		
		
	}
	
	//Displaying the data
	public List<Bank> getCustomerDetails() {
		return list;
	}
	
	//Displaying the deposited data
	
}
