package com.cg.session.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.session.bean.Session;
import com.cg.session.dao.SessionDao;
import com.cg.session.exception.SessionException;

@Service
public class SessionServiceImpl implements ISessionService{

	@Autowired
	SessionDao sessionDao; 
	
	/*
	Author : Vyshnavi Muthumula
	Date of Duration : 30/1/2019
	Method Name : createSession
	Parameters : Parameters of type session
	Return value : Returns session details
	Purpose : To create a session adn autowiring is for checking the name 
	*/
	
	@Override
	public List<Session> createSession(Session session) throws SessionException {
		try {
			sessionDao.save(session);
			return sessionDao.findAll();
		}catch(Exception e) {
			throw new SessionException("Duration must be greater than 3 and mode of session either ILT or VC");
		}
	}

	/*
	Author : Vyshnavi Muthumula
	Date of Duration : 30/1/2019
	Method Name : updateSession
	Parameters : Parameters of type integer as id and session
	Return value : Returns session details
	Purpose : To update the session
	*/
	
	
	@Override
	public List<Session> updateSession(Integer id, Session session) throws SessionException {
		try {
			Optional<Session> optional=sessionDao.findById(id);
			Session sessions=optional.get();
			sessions.setDuration(session.getDuration());
			sessions.setFaculty(session.getFaculty());
			sessionDao.save(sessions);
			return viewAllSessions();
		}catch(Exception e) {
			throw new SessionException("Duration not more than 3");
		}
	}
	
	/*
	Author : Vyshnavi Muthumula
	Date of Duration : 30/1/2019
	Method Name : viewAllSessions
	Parameters : Parameters of type integer as id and session
	Return value : Returns session details and if there is any exception it prints that exception
	Purpose : To view the session
	*/

	@Override
	public List<Session> viewAllSessions() throws SessionException {
		try {
			return sessionDao.findAll();
		}catch(Exception e) {
			throw new SessionException(e.getMessage());
		}
	}

	/*
	Author : Vyshnavi Muthumula
	Date of Duration : 30/1/2019
	Method Name : deleteSession
	Parameters : Parameters of type integer as id
	Return value : Returns session details and if there is any exception it prints that exception
	Purpose : To delete the session using id
	*/
	
	@Override
	public List<Session> deleteSession(Integer id) throws SessionException {
		try {
			sessionDao.deleteById(id);
			return sessionDao.findAll();
		}catch(Exception e) {
			throw new SessionException(e.getMessage());
		}
		
	}

}
